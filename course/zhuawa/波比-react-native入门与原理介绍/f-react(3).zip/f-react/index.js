const isArr = Array.isArray
const toArray = arr => isArr(arr ?? []) ? arr : [arr]
const isText = txt => typeof txt === 'string' || typeof txt === 'number'
const flatten = arr =>
  [...arr.map(ar => isArr(ar)
    ? [...flatten(ar)]
    : isText(ar) ? createTextVNode(ar) : ar)]
// <div className='empty'>hello world!</div> 
// babel-plugin-jsx-transform -> h('div', { className: 'empty' }, 'hello world!')
export function h(type, props, ...kids) {
  props = props ?? {}
  kids = flatten(toArray(props.children ?? kids)).filter(Boolean)
  if (kids.length) props.children = kids.length === 1 ? kids[0] : kids

  const key = props.key ?? null
  const ref = props.ref ?? null

  delete props.key
  delete props.ref

  return createVNode(type, props, key, ref)
}

function createTextVNode(text) {
  return {
    type: '',
    props: { nodeValue: text + '' }
  }
}

function createVNode(type, props, key, ref) {
  return {
    type, props, key, ref
  }
}

export function Fragment(props) {
  return props.children
}

// scheduler
/**
 * schedule -> 把任务放进一个队列，然后开始（以某种节奏[ric (requestIdleCallback)]执行）
 * shouldYield -> should yield -> generator yiled. (本质上，就是返回 true/false 的函数)
 */

const queue = []
const threshold = 1000 / 60

// git transtions
const transtions = []
let deadline = 0

const now = () => performance.now()
const peek = arr => arr[0]

export function startTranstion(cb) {
  transtions.push(cb) && postMessage()
}

// 二合一，push / exec
export function schedule (cb) {
  queue.push({ cb })
  startTranstion(flush)
}

// 触发宏任务，渲染 / 宏任务
const postMessage = (() => {
  const cb = () => transtions.splice(0, 1).forEach(c => c())
  const { port1, port2 } = new MessageChannel()
  port1.onmessage = cb
  return () => port2.postMessage(null)
})()

export function shouldYield () {
  return navigator.scheduling.isInputPending() || now() >= deadline
}

function flush() {
  deadline = now() + threshold
  let task = peek(queue)

  while(task && !shouldYield()) {
    const { cb } = task
    task.cb = null
    const next = cb()

    if (next && typeof next === 'function') {
      task.cb = next
    }
    else {
      queue.shift()
    }

    task = peek(queue)
  }

  task && startTranstion(flush)
}

