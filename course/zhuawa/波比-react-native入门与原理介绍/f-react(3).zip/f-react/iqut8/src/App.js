import "./styles.css";
import { useState } from "react";

export default function App() {
  const [counter, updateCounter] = useState(0);
  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
      <h2>Start editing to see some magic happen!</h2>
      <div className="App-intro">
        <div className="button-container">
          <button
            className="decrement-button"
            onClick={() => updateCounter((counter) => counter - 1)}
          >
            -
          </button>
          <div className="counter-text">{counter}</div>
          <button
            className="increment-button"
            onClick={() => updateCounter((counter) => counter + 1)}
          >
            +
          </button>
        </div>
      </div>
    </div>
  );
}
