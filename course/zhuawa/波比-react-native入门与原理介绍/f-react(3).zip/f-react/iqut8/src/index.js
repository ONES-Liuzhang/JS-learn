import { StrictMode } from "react";
// import ReactDOM from "react-dom";
import XDOM from './MyRender';

import App from "./App";

const rootElement = document.getElementById("root");
XDOM.render(
  <StrictMode>
    <App />
  </StrictMode>,
  rootElement
);
