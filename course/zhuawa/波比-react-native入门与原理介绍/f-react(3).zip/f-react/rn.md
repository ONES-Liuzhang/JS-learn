# React Native

## react-native 是什么？

![rn](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c0372c7df58e4b6584cae190862611a1~tplv-k3u1fbpfcp-zoom-1.image)

上图是老的架构，面对 `flutter` 的压力，`FB` 团队目前决定在新的架构使用 `JSI` 等解决了之前 `bridge` 的问题【1、JSON 传输，序列化 2、异步通信队列】

目前的代码大部分还是向前兼容的，很多 `feature` 还在开发中，进度低于预期

### 流程梳理

1. 注册应用

```jsx
function App() {
  return (
    <Text>hello world!</Text>
  )
}

AppRegistry.registerComponent('test', () => App)
```

`RN` 的入口处注册了应用，那背后到底干了什么？

```js
// 忽略了大部分代码
// 源代码地址：https://github.com/facebook/react-native/blob/afe0c1daea0aaf7b40b7ded08d6eb6d45b17099c/Libraries/ReactNative/AppRegistry.js
const runnables = {}
const AppRegistry = {
  registerComponent(
    appKey: string,
    componentProvider: ComponentProvider,
    section?: boolean,
  ): string {
    let scopedPerformanceLogger = createPerformanceLogger();
    // 存起来
    runnables[appKey] = {
      componentProvider,
      run: (appParameters, displayMode) => {
        // 看名字就知道不简单，render 应用，就看在哪儿执行了
        renderApplication(
          componentProviderInstrumentationHook(
            componentProvider,
            scopedPerformanceLogger,
          ),
          appParameters.initialProps,
          appParameters.rootTag,
          wrapperComponentProvider && wrapperComponentProvider(appParameters),
          appParameters.fabric,
          showArchitectureIndicator,
          scopedPerformanceLogger,
          appKey === 'LogBox',
          appKey,
          coerceDisplayMode(displayMode),
          appParameters.concurrentRoot,
        );
      },
    };
    if (section) {
      sections[appKey] = runnables[appKey];
    }
    return appKey;
  }
}
```

2. 客户端启动

```java
/** Interface for the root native view of a React native application */
public interface ReactRoot {
  // 源代码：https://github.com/facebook/react-native/blob/cc13060d70cb55650f621ea75d01dabf38962850/ReactAndroid/src/main/java/com/facebook/react/uimanager/ReactRoot.java#L17
  // 省略了大部分的代码
  /** Calls into JS to start the React application. */
  void runApplication();
}

```

跟着看看 `runApplication` 调用，就是找那个 `Java` 模块实现了 `ReactRoot`

```java
 /**
   * Calls into JS to start the React application. Can be called multiple times with the same
   * rootTag, which will re-render the application from the root.
   */

  // 源代码位置：https://github.com/facebook/react-native/blob/cc13060d70cb55650f621ea75d01dabf38962850/ReactAndroid/src/main/java/com/facebook/react/ReactRootView.java
  @Override
  public void runApplication() {
    Systrace.beginSection(TRACE_TAG_REACT_JAVA_BRIDGE, "ReactRootView.runApplication");
    try {
      if (mReactInstanceManager == null || !mIsAttachedToInstance) {
        return;
      }

      ReactContext reactContext = mReactInstanceManager.getCurrentReactContext();
      if (reactContext == null) {
        return;
      }

      CatalystInstance catalystInstance = reactContext.getCatalystInstance();
      String jsAppModuleName = getJSModuleName();

      if (mWasMeasured) {
        updateRootLayoutSpecs(true, mWidthMeasureSpec, mHeightMeasureSpec);
      }

      WritableNativeMap appParams = new WritableNativeMap();
      appParams.putDouble("rootTag", getRootViewTag());
      @Nullable Bundle appProperties = getAppProperties();
      if (appProperties != null) {
        appParams.putMap("initialProps", Arguments.fromBundle(appProperties));
      }

      mShouldLogContentAppeared = true;

      // ⚠️ 关注这里
      catalystInstance.getJSModule(AppRegistry.class).runApplication(jsAppModuleName, appParams);
    
    } finally {
      Systrace.endSection(TRACE_TAG_REACT_JAVA_BRIDGE);
    }
  }
```

最终调用了 `js` 方法 `runApplication`

```js
/**
   * Loads the JavaScript bundle and runs the app.
   *
   * See https://reactnative.dev/docs/appregistry.html#runapplication
   */

  // 源代码：https://github.com/facebook/react-native/blob/afe0c1daea0aaf7b40b7ded08d6eb6d45b17099c/Libraries/ReactNative/AppRegistry.js
  runApplication(
    appKey: string,
    appParameters: any,
    displayMode?: number,
  ): void {
    // 最终这一行执行了
    runnables[appKey].run(appParameters, displayMode);
  }
```

所以会执行 `renderApplication` 方法

```js
// 源代码：https://github.com/facebook/react-native/blob/afe0c1daea0aaf7b40b7ded08d6eb6d45b17099c/Libraries/ReactNative/renderApplication.js#L24
function renderApplication<Props: Object>(
  RootComponent: React.ComponentType<Props>,
  initialProps: Props,
  rootTag: any,
  WrapperComponent?: ?React.ComponentType<any>,
  fabric?: boolean,
  showArchitectureIndicator?: boolean,
  scopedPerformanceLogger?: IPerformanceLogger,
  isLogBox?: boolean,
  debugName?: string,
  displayMode?: ?DisplayModeType,
  useConcurrentRoot?: boolean,
) {
  // 省略大部分代码
  // 这里的 fabric 是新架构的东西，这里做了向前兼容
  if (fabric) {
    require('../Renderer/shims/ReactFabric').render(
      renderable,
      rootTag,
      null,
      useConcurrentRoot,
    );
  } else {
    // ⚠️ 我们关注这里就行
    require('../Renderer/shims/ReactNative').render(renderable, rootTag);
  }
}
```

现在是我们熟悉的部分，`Fiber`

```js
// https://github.com/facebook/react-native/blob/afe0c1daea/Libraries/Renderer/implementations/ReactNativeRenderer-dev.js#L22967
function render(element, containerTag, callback) {
  var root = roots.get(containerTag);

  if (!root) {
    // TODO (bvaughn): If we decide to keep the wrapper component,
    // We could create a wrapper for containerTag as well to reduce special casing.
    root = createContainer(containerTag, LegacyRoot, false, null, false);
    roots.set(containerTag, root);
  }

  // ⚠️：从这里开始
  updateContainer(element, root, null, callback); // $FlowIssue Flow has hardcoded values for React DOM that don't work with RN

  return getPublicRootInstance(root);
}

// 先关注一下返回
function getPublicRootInstance(container) {
  var containerFiber = container.current;

  if (!containerFiber.child) {
    return null;
  }

  switch (containerFiber.child.tag) {
    // hostcomponent: 原生组件
    case HostComponent:
      // getPublicInstance： i => i
      return getPublicInstance(containerFiber.child.stateNode);

    default:
      // stateNode：原生dom节点或者虚拟组件实例
      return containerFiber.child.stateNode;
  }
}

// 然后看看，updateContainer
function updateContainer(element, container, parentComponent, callback) {

  // root fiber
  var current$1 = container.current;

  // 计时 使用 performance.now
  var eventTime = requestEventTime();

  // lane!!! 获取优先级
  // 这个方法本质就是一堆 if 条件判断然后返回不同的优先级
  var lane = requestUpdateLane(current$1);

  // 上下文 context
  var context = getContextForSubtree(parentComponent);

  // 创建一个 update，其实该方法就是就是一个对象
  // var update = {
  //   eventTime: eventTime,
  //   lane: lane,
  //   tag: UpdateState,
  //   payload: null,
  //   callback: null,
  //   next: null
  // };
  var update = createUpdate(eventTime, lane);

  // sheduler 登场，第一步，插入更新（会计算优先级）
  enqueueUpdate(current$1, update);

  // 开始调度
  var root = scheduleUpdateOnFiber(current$1, lane, eventTime);

  if (root !== null) {
    entangleTransitions(root, current$1, lane);
  }

  return lane
}

// 调度执行的
function scheduleUpdateOnFiber(fiber, lane, eventTime) {
  // 1. 避免死循环
  checkForNestedUpdates();

  // 2. 上报 lanes
  var root = scheduleUpdateOnFiber(fiber, lane, eventTime);

  // 3. 标记更新
  markRootUpdated(root, lane, eventTime);
}

// flushSyncCallbackQueue
// flushSyncCallbackQueueImpl
// runWithPriority
// performSyncWorkOnRoot
// workLoopSync
// performUnitOfWork
// completeWork
```

`completeWork` 中发现玄机，里面调用了 `createInstance`

```js
function createInstance(
  type,
  props,
  rootContainerInstance,
  hostContext,
  internalInstanceHandle
) {
  var tag = allocateTag();
  var viewConfig = getViewConfigForType(type);

  {
    for (var key in viewConfig.validAttributes) {
      if (props.hasOwnProperty(key)) {
        ReactNativePrivateInterface.deepFreezeAndThrowOnMutationInDev(
          props[key]
        );
      }
    }
  }

  var updatePayload = create(props, viewConfig.validAttributes);
  // UIManager 开始创建视图了
  ReactNativePrivateInterface.UIManager.createView(
    tag, // reactTag
    viewConfig.uiViewClassName, // viewName
    rootContainerInstance, // rootTag
    updatePayload // props
  );
  var component = new ReactNativeFiberHostComponent(
    tag,
    viewConfig,
    internalInstanceHandle
  );
  precacheFiberNode(internalInstanceHandle, tag);
  updateFiberProps(tag, props); // Not sure how to avoid this cast. Flow is okay if the component is defined
  // in the same file but if it's external it can't see the types.

  return component;
}
```

再看看客户端，怎么实现 `createView`

```java
// https://github.com/facebook/react-native/blob/1465c8f3874cdee8c325ab4a4916fda0b3e43bdb/ReactAndroid/src/main/java/com/facebook/react/uimanager/UIManagerModule.java
@ReactMethod
public void createView(int tag, String className, int rootViewTag, ReadableMap props) {
  if (DEBUG) {
    String message =
        "(UIManager.createView) tag: " + tag + ", class: " + className + ", props: " + props;
    FLog.d(ReactConstants.TAG, message);
    PrinterHolder.getPrinter().logMessage(ReactDebugOverlayTags.UI_MANAGER, message);
  }
  mUIImplementation.createView(tag, className, rootViewTag, props);
}

// 最后通过 ViewManager 完成绘制
```

## 补充一些资料

[RN 实战踩坑](https://github.com/crazycodeboy/RNStudyNotes)

[awesome rn](https://github.com/jondot/awesome-react-native)

[30days of rn](https://github.com/fangwei716/30-days-of-react-native)

[issues](https://github.com/react-native-community/discussions-and-proposals/issues)

[build your render](https://www.youtube.com/watch?v=CGpMlWVcHok&ab_channel=ReactConf)


## 跨端方案

react-native
  - ios / adr ✅
  - pc / react-native-web ✅
  - wx / remax ✅


react-native-web：
原理：粗暴，rn 的所有的组件，它都用 h5 写了一套

```js
import { View, Text } from 'react-native'

function A() {
  return <View><Text>hello world!</Text></View>
}
```
webpack -> alias -> 'react-native': 'react-native-web'

remax:
原理：
  hostConfig -> react-reconciler -> rinsts.updateContainer -> RemaxVnode
  -> remax-cli (RemaxVnode) -> wx-template -> wx-render

