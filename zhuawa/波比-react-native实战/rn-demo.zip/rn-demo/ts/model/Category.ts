export interface ICategory {
  id: number;
  name: string;
  bgPicture: string;
  headerImage: string;
}
