export interface ITopicList {
  data: ITopicModel;
}

export interface ITopicModel {
  id: number;
  image: string;
}
