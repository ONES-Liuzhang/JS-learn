export interface ITab {
  id: number;
  name: string;
  apiUrl: string;
}
