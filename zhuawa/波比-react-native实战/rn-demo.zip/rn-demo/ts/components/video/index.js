import Video from './Video';
export default Video;
