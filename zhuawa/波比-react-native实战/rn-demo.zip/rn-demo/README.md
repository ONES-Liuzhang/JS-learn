# react-native 开发

> 总结一些最佳实践，并没有严格的顺序

1. 启动项目

rn 的项目一般都很难一次性跑起来（😭），这个开源项目一样，我改了 `podfile` 文件才顺利跑起来

[改了一下 Podfile](https://github.com/react-native-community/upgrade-support/issues/155#issuecomment-839149803)

> 当然可能你遇到的情况会不一样，反正 `google` 一下

[libwebp 安装不下来的话](https://zhuanlan.zhihu.com/p/355316931)

[pod install 太慢的话](https://zhuanlan.zhihu.com/p/335715225)

都搞定了的话：

```shell
cd ios && pod install && yarn ios
```

这个项目大概的技术栈：

![stack](https://raw.githubusercontent.com/fmtjava/ReactNative_Eyepetizer/main/images/technologystack.png)

2. 开屏画面

[react-native-splash-screen集成实践（ios & android）](https://zhuanlan.zhihu.com/p/29495955)

[react-native-splash-screen](https://github.com/crazycodeboy/react-native-splash-screen#readme)

3. 状态管理

`rn` 项目可以使用 `react` 生态体系，`react` 在复杂程度高的大型项目构建上，推荐使用状态管理工具，比如 `redux`, `mobx` 以及二次封装类的工具 `dva`, `rematch` 等

> 还是那个问题，你不一定需要状态管理工具，根据项目的复杂度去判断

这个项目使用的是 `sorrycc` 的 [dva](https://dvajs.com/guide/)

4. 路由管理

[react-navigation](https://reactnavigation.org/docs/getting-started)

上手也很简单，基本看文档就可以完整撸下来，不过在做多端统一方案的时候，这个路由库有坑，可以换成社区的别的库，比如[react-native-router-flux](https://github.com/aksonov/react-native-router-flux)

5. portal 方案

[react-native-root-siblings](https://github.com/magicismight/react-native-root-siblings)

基本还是利用这个库实现根节点同级效果

原理：https://github.com/magicismight/react-native-root-siblings/blob/master/src/RootSiblingsManager.tsx#L19

6. 优雅图标方案

> svg vs iconfont

> png jpg jpeg webp ?

[react-native-vector-icons](https://github.com/oblador/react-native-vector-icons)

[react-native-iconfont-cli](https://github.com/iconfont-cli/react-native-iconfont-cli)

[react-native-svg](https://github.com/react-native-svg/react-native-svg)

如果考虑多端统一方案，可参考[这里](https://juejin.cn/post/6844903668374847501)

7. 图片

这里使用的是 [fast-image](https://github.com/DylanVann/react-native-fast-image)

使用比较方便，当然社区还有一些别的图片相关的库可以使用

8. 视频

首选还是这个库，

[react-native-video](https://github.com/react-native-video/react-native-video)

基于此库封装

9. iphonex 适配

[react-native-iphone-x-helper](https://github.com/ptelad/react-native-iphone-x-helper)

原理就是判断是不是 `iphonex` 如果是的话，通过 `padding` 把距离让出去

10. 物理返回监听

可以单独封装一个监听工具，然后在需要的地方调用就行

```jsx
export class BackPressComponent {
  handler: () => boolean | null | undefined;
  constructor(props: IProps) {
    this.handler = props.handler;
  }
  //模拟组件声明周期
  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', this.handler);
  }

  componentWillUnmount() {
    BackHandler.removeEventListener('hardwareBackPress', this.handler);
  }
}

// 使用
class SomeDemo extends React.PureComponent {
  constructor(props: IProps) {
    super(props);
    this.backPress = new BackPressComponent({
      handler: this.onBackPress,
    });
  }

  componentDidMount() {
    this.backPress?.componentDidMount();
  }

  componentWillUnmount() {
    this.backPress?.componentWillUnmount();
  }

  // 其余代码省略...
}
```

11. 自适应

[可参考](https://zhuanlan.zhihu.com/p/55826586)

举例说明，比如文本大小，[前置知识](http://www.ayqy.net/blog/%E5%AE%8C%E5%85%A8%E7%90%86%E8%A7%A3px-dpr-dpi-dip/)

12. style 写起来太呕?

这个可以做到工具层面，基本上还是得利用 [css-to-react-native](https://github.com/styled-components/css-to-react-native);

我之前在项目里搞了一套，效果还行

原理就是 `less` -> `less loader` -> `css string` -> `css-to-react-native` -> `style object` -> `rn style`

13. 简化文件路径

这是一个小 `tip`，通过 `ts` 和 `babel-plugin` 就可以实现

```js
// in tsconfig.json
"paths": {
  "@/assets/*": ["assets/*"],
  "@/components/*": ["components/*"],
  "@/config/*": ["config/*"],
  "@/model/*": ["model/*"],
  "@/navigator/*": ["navigator/*"],
  "@/page/*": ["page/*"],
  "@/utils/*": ["utils/*"],
},  

// in babel.config.js
plugins: [
  [
    'module-resolver',
    {
      root: ['./ts'],
      alias: {
        '@/assets': './ts/assets',
        '@/components': './ts/components',
        '@/config': './ts/config',
        '@/model': './ts/model',
        '@/navigator': './ts/navigator',
        '@/page': './ts/page',
        '@/utils': './ts/utils',
      },
    },
  ],
],
```

原理就是利用 `babel` 在编译的时候做了字符串替换，把路径换成了相对/绝对路径

14. 依赖包的版本锁定问题

```jsx
// 你能区分吗？
"react": "15.2.1",
"react": "~15.2.1",
"react": "^15.2.1",
```

这其实是一个很细微但是很严重的问题，不知道大家踩过坑儿没有

[参考](https://imweb.io/topic/5c27ca84611a25cc7bf1d85d)

15. 不要过早的去解决性能问题

「性能优化」这个词儿听起来是很牛逼

> 过早的性能优化，是万恶之源 -- 鲁迅

[这种优化一定是在开发完成后，再慢慢来搞](http://www.alloyteam.com/2016/03/best-practice-in-react-native/)

16. 骨架屏方案

业界方案翻来覆去不外乎那几种，根据实际项目的需求选择合适的

我总结的大致是：
 - 组件流 （也就是写 Skelton 组件代替 loading，但是不能很好的解决首屏骨架问题）
 - 脚本流 （通过一些工具，骨架代码而已，本质上还是要回到第一种，只是减少开销）

17. 多端统一方案

这个是目前业内各厂都感兴趣的东东，同学们如果有兴趣可以在这个方向上做点东西，提升自己简历的精彩程度

[去哪儿网的方案](https://www.infoq.cn/article/hkoihlwvmxwro2u94e9i)

其余的没咋看到开源的，不过原理都是那三板斧

1、RN -> Web

这个基本还是用了 `twitter` 的那个库 `react-native-web`

2、RN -> Mini App

转小程序的话，不得不说，就只有两种方案：

1）编译型

2）运行时

为了保证和 `React` 生态最大的兼容，以及切换开销，目前基本都是使用的运行时方案，代表性的就是 `taro next`，`remax`
