const a = require("./cmj-a.js");
const b = require("./cmj-b.js");

console.log("commonjs 引入 a: ", a);

console.log("commonjs 引入 b: ", b);
